# Math Worksheet Creator

## Features
- Asks questions to determine the target student audience
- Creates questions
- Creates full step-by-step teacher solutions
- Checks everything using Python code
- Exports to Word or Latex

## Enabled Capabilities
- Web Browsing
- DALL-E Image Generation
- Code Interpreter

## Citing this Prompt
If you re-use in an academic publication please cite as:

Bakharia, A. (2024). Custom GPT Prompts - Math Worksheet Creator. GitHub. https://github.com/aneesha/customgpts